# Fake Profile Detection System

A Flask-based machine learning project that detects fake social media profiles.

## Features
- Detect fake Instagram profiles
- Machine learning models
- Flask web interface

## Technologies
- Python
- Flask
- Scikit-Learn
- HTML/CSS

## Run Project

pip install -r requirements.txt
python app.py
For demonstration, try using these example fake account URLs:
- [https://www.instagram.com/fakeprofile1/](https://www.instagram.com/fakeprofile1/)
- [https://www.instagram.com/spamaccount/](https://www.instagram.com/spamaccount/)
- [https://www.instagram.com/quickmoneyguru/](https://www.instagram.com/quickmoneyguru/)

If the profile data cannot be fetched (for example, if the profile is private), dummy demo data will be used.


