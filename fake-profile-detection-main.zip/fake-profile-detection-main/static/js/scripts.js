// static/js/scripts.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("Fake Buster app loaded.");
});
