import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
import json

np.random.seed(42)
n_samples = 1000

# Generate synthetic features
username_length = np.random.randint(3, 16, n_samples)
fullname_length = np.random.randint(5, 31, n_samples)
email_suspicious = np.zeros(n_samples, dtype=int)  # Not used for Instagram
bio_length = np.random.randint(0, 151, n_samples)
image_width = np.random.randint(50, 501, n_samples)
image_height = np.random.randint(50, 501, n_samples)

df = pd.DataFrame({
    'username_length': username_length,
    'fullname_length': fullname_length,
    'email_suspicious': email_suspicious,
    'bio_length': bio_length,
    'image_width': image_width,
    'image_height': image_height
})

# Create a synthetic "score" based on thresholds.
score = (
    0.2 * (username_length < 4).astype(int) +
    0.2 * (fullname_length < 6).astype(int) +
    0.3 * (bio_length < 10).astype(int) +
    0.15 * (image_width < 150).astype(int) +
    0.15 * (image_height < 150).astype(int)
)

labels = (score > 0.5).astype(int)
df['label'] = labels

X = df.drop("label", axis=1)
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train SVM (with probability estimates)
svm_model = SVC(probability=True, random_state=42)
svm_model.fit(X_train, y_train)
svm_accuracy = svm_model.score(X_test, y_test)
joblib.dump(svm_model, "svm_model.pkl")

# Train Neural Network (MLPClassifier)
nn_model = MLPClassifier(random_state=42, max_iter=1000)
nn_model.fit(X_train, y_train)
nn_accuracy = nn_model.score(X_test, y_test)
joblib.dump(nn_model, "nn_model.pkl")

# Train Random Forest
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
rf_accuracy = rf_model.score(X_test, y_test)
joblib.dump(rf_model, "rf_model.pkl")

accuracy_results = {
    "SVM Accuracy": svm_accuracy,
    "Neural Network Accuracy": nn_accuracy,
    "Random Forest Accuracy": rf_accuracy
}
with open("model_accuracies.json", "w") as f:
    json.dump(accuracy_results, f)

print("Models saved and accuracies stored in model_accuracies.json")
